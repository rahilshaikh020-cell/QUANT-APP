# QuantEdge AI — Institutional Stock Research, Value Investing & Trading Signal Platform

A full-stack quantitative equity research, fundamental valuation, anomaly detection, and walk-forward backtesting platform covering **2,000+ NSE, BSE, and US equities**.

## 1. Architecture Overview

- **Interactive Web Application (`quant_stock_platform.html`)**: Self-contained, responsive financial terminal supporting all 13 modules (Dashboard, 2,000+ Stock Screener, Interactive Candlestick Stock Detail, Swing Trading Engine, Value Investing Scanner, Falling Knife Detector, Pump-and-Dump & False Breakout Detector, Walk-Forward Backtesting Lab, Point-in-Time Signal History, Portfolio Tracker, Grounded AI Research Assistant, Strategy Monitor, and Settings).
- **Backend Quantitative Engine (`backend/app/quant_engine.py` & `main.py`)**: Python + FastAPI + Pandas/NumPy engine implementing causal technical indicators, corporate-action adjustments, sector-specific intrinsic value models, and `T+1 Open` walk-forward backtests with Indian STT/Stamp/GST/Slippage cost deduction.
- **Database Schema (`migrations/001_initial_schema.sql`)**: PostgreSQL + TimescaleDB hypertables storing active and delisted securities, corporate actions, and point-in-time (`public_filing_timestamp`) fundamentals to eliminate survivorship and look-ahead bias.
- **Data Provider Adapters (`backend/app/data_providers.py`)**: Pluggable adapter interface supporting licensed Indian/US feeds (Zerodha Kite Connect, TrueData, NSE EOD Bhavcopy, Polygon.io, AlphaVantage) and verified point-in-time snapshots with explicit `LIVE`, `DELAYED_15M`, `EOD`, `HISTORICAL_PIT`, and `DATA_UNAVAILABLE` states.

## 2. Local Setup & Execution

```bash
# 1. Configure environment variables
cp .env.example .env

# 2. Apply PostgreSQL + TimescaleDB migrations
psql "$DATABASE_URL" -f migrations/001_initial_schema.sql

# 3. Run the automated verification & test suite
PYTHONPATH=. pytest backend/tests/test_quant_engine.py -v

# 4. Start the FastAPI server
uvicorn backend.app.main:app --host 0.0.0.0 --port 8000 --reload
```

## 3. REST API Endpoints

- `GET /api/v1/health`: Engine status, look-ahead protection mode, and active market adapters.
- `POST /api/v1/analyze`: Runs corporate-action adjustment, causal indicators, falling-knife & pump-dump detection, sector-specific DCF/Multiple valuation, walk-forward OOS backtesting, and rule-based `BUY / HOLD / SELL / WAIT / AVOID` classification.
