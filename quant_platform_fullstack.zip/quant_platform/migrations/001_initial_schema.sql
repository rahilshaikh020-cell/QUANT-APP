-- =============================================================================
-- PROJECT: AI-POWERED STOCK RESEARCH, VALUE INVESTING & TRADING SIGNAL PLATFORM
-- Migration 001: Core Relational & TimescaleDB Point-in-Time Schema
-- Prevents survivorship bias and look-ahead bias via filing_date timestamps
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS timescaledb CASCADE;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- 1. Stock Universe (Includes active and delisted securities to prevent survivorship bias)
CREATE TABLE IF NOT EXISTS stocks (
    stock_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ticker VARCHAR(32) NOT NULL,
    exchange VARCHAR(16) NOT NULL CHECK (exchange IN ('NSE', 'BSE', 'NASDAQ', 'NYSE')),
    isin VARCHAR(20),
    company_name VARCHAR(255) NOT NULL,
    sector VARCHAR(100) NOT NULL,
    industry VARCHAR(120) NOT NULL,
    market_cap_category VARCHAR(20) NOT NULL CHECK (market_cap_category IN ('LARGE_CAP', 'MID_CAP', 'SMALL_CAP')),
    currency VARCHAR(8) NOT NULL DEFAULT 'INR',
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    listing_date DATE,
    delisting_date DATE,
    delisting_reason VARCHAR(255),
    data_provider VARCHAR(64) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (ticker, exchange)
);

CREATE INDEX idx_stocks_sector ON stocks(sector);
CREATE INDEX idx_stocks_mcap_cat ON stocks(market_cap_category);
CREATE INDEX idx_stocks_active ON stocks(is_active);

-- 2. Historical & Intraday OHLCV Bars (TimescaleDB Hypertable)
CREATE TABLE IF NOT EXISTS ohlcv_bars (
    stock_id UUID NOT NULL REFERENCES stocks(stock_id) ON DELETE CASCADE,
    bar_time TIMESTAMPTZ NOT NULL,
    timeframe VARCHAR(8) NOT NULL DEFAULT '1D', -- 1D, 1W, 1H, 15M
    open_raw NUMERIC(18, 4) NOT NULL,
    high_raw NUMERIC(18, 4) NOT NULL,
    low_raw NUMERIC(18, 4) NOT NULL,
    close_raw NUMERIC(18, 4) NOT NULL,
    volume_raw BIGINT NOT NULL,
    adj_factor NUMERIC(18, 8) NOT NULL DEFAULT 1.0,
    open_adj NUMERIC(18, 4) NOT NULL,
    high_adj NUMERIC(18, 4) NOT NULL,
    low_adj NUMERIC(18, 4) NOT NULL,
    close_adj NUMERIC(18, 4) NOT NULL,
    volume_adj BIGINT NOT NULL,
    vwap NUMERIC(18, 4),
    delivery_pct NUMERIC(6, 2), -- NSE/BSE delivery volume percentage
    spread_bps NUMERIC(8, 2),
    data_freshness VARCHAR(20) NOT NULL CHECK (data_freshness IN ('LIVE', 'DELAYED_15M', 'EOD', 'HISTORICAL_PIT')),
    source_provider VARCHAR(64) NOT NULL,
    PRIMARY KEY (stock_id, bar_time, timeframe)
);

SELECT create_hypertable('ohlcv_bars', 'bar_time', if_not_exists => TRUE);

-- 3. Corporate Actions (Splits, Dividends, Bonus, Rights)
CREATE TABLE IF NOT EXISTS corporate_actions (
    action_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    stock_id UUID NOT NULL REFERENCES stocks(stock_id) ON DELETE CASCADE,
    ex_date DATE NOT NULL,
    record_date DATE,
    action_type VARCHAR(24) NOT NULL CHECK (action_type IN ('SPLIT', 'BONUS', 'DIVIDEND', 'RIGHTS', 'MERGER')),
    ratio_from NUMERIC(12, 4),
    ratio_to NUMERIC(12, 4),
    cash_dividend_per_share NUMERIC(18, 4),
    adjustment_multiplier NUMERIC(18, 8) NOT NULL DEFAULT 1.0,
    source_reference VARCHAR(255),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_corp_actions_stock_date ON corporate_actions(stock_id, ex_date);

-- 4. Point-in-Time Fundamental Statements
-- CRITICAL: Uses public_filing_timestamp so backtests NEVER use earnings before they were publicly released.
CREATE TABLE IF NOT EXISTS fundamentals_pit (
    fundamental_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    stock_id UUID NOT NULL REFERENCES stocks(stock_id) ON DELETE CASCADE,
    period_end_date DATE NOT NULL,
    public_filing_timestamp TIMESTAMPTZ NOT NULL, -- Point-in-time availability gate
    period_type VARCHAR(10) NOT NULL CHECK (period_type IN ('Q1', 'Q2', 'Q3', 'Q4', 'FY', 'TTM')),
    revenue NUMERIC(20, 2) NOT NULL,
    operating_profit NUMERIC(20, 2) NOT NULL,
    net_profit NUMERIC(20, 2) NOT NULL,
    eps NUMERIC(14, 4) NOT NULL,
    operating_cash_flow NUMERIC(20, 2),
    capex NUMERIC(20, 2),
    free_cash_flow NUMERIC(20, 2),
    total_debt NUMERIC(20, 2),
    cash_and_equivalents NUMERIC(20, 2),
    shareholders_equity NUMERIC(20, 2),
    book_value_per_share NUMERIC(14, 4),
    shares_outstanding BIGINT NOT NULL,
    roe_pct NUMERIC(8, 2),
    roic_pct NUMERIC(8, 2),
    operating_margin_pct NUMERIC(8, 2),
    net_margin_pct NUMERIC(8, 2),
    debt_to_equity NUMERIC(10, 3),
    interest_coverage NUMERIC(10, 2),
    current_ratio NUMERIC(8, 2),
    promoter_holding_pct NUMERIC(6, 2),
    promoter_pledge_pct NUMERIC(6, 2),
    auditor_qualification_flag BOOLEAN NOT NULL DEFAULT FALSE,
    restatement_flag BOOLEAN NOT NULL DEFAULT FALSE,
    UNIQUE (stock_id, period_end_date, period_type, public_filing_timestamp)
);

CREATE INDEX idx_fundamentals_pit_lookup ON fundamentals_pit(stock_id, public_filing_timestamp DESC);

-- 5. Explainable Signals Audit Log
CREATE TABLE IF NOT EXISTS signals_audit_log (
    signal_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    stock_id UUID NOT NULL REFERENCES stocks(stock_id) ON DELETE CASCADE,
    generated_at TIMESTAMPTZ NOT NULL,
    strategy_id VARCHAR(64) NOT NULL,
    strategy_horizon VARCHAR(32) NOT NULL, -- SWING_3_15D, POSITIONAL_2_8W, VALUE_1_3Y, VALUE_3_5Y, VALUE_5Y_PLUS
    action_state VARCHAR(16) NOT NULL CHECK (action_state IN ('BUY', 'HOLD', 'SELL', 'WAIT', 'AVOID')),
    fundamental_rating VARCHAR(24) NOT NULL CHECK (fundamental_rating IN ('HIGH_QUALITY_UNDERVALUED', 'QUALITY_FAIR_PRICE', 'OVERVALUED_QUALITY', 'DETERIORATING', 'VALUE_TRAP')),
    current_price NUMERIC(18, 4) NOT NULL,
    entry_zone_low NUMERIC(18, 4),
    entry_zone_high NUMERIC(18, 4),
    stop_loss_price NUMERIC(18, 4),
    stop_loss_method VARCHAR(120),
    target_1_price NUMERIC(18, 4),
    target_2_price NUMERIC(18, 4),
    exit_method VARCHAR(120),
    upside_pct NUMERIC(8, 2),
    downside_risk_pct NUMERIC(8, 2),
    risk_reward_ratio NUMERIC(8, 2),
    calibrated_confidence_pct NUMERIC(6, 2) NOT NULL,
    calibration_method VARCHAR(120) NOT NULL,
    falling_knife_risk VARCHAR(16) NOT NULL CHECK (falling_knife_risk IN ('LOW', 'MODERATE', 'HIGH', 'EXTREME')),
    pump_dump_status VARCHAR(48) NOT NULL,
    validation_status VARCHAR(20) NOT NULL CHECK (validation_status IN ('VALIDATED', 'UNVALIDATED')),
    reasons_json JSONB NOT NULL,
    counterarguments_json JSONB NOT NULL,
    data_warnings_json JSONB NOT NULL DEFAULT '[]'::jsonb
);

CREATE INDEX idx_signals_stock_time ON signals_audit_log(stock_id, generated_at DESC);

-- 6. Backtest Runs & Walk-Forward Validation Results
CREATE TABLE IF NOT EXISTS backtest_runs (
    run_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    stock_id UUID NOT NULL REFERENCES stocks(stock_id) ON DELETE CASCADE,
    strategy_id VARCHAR(64) NOT NULL,
    executed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    in_sample_start DATE NOT NULL,
    in_sample_end DATE NOT NULL,
    oos_start DATE NOT NULL,
    oos_end DATE NOT NULL,
    total_return_pct NUMERIC(10, 2) NOT NULL,
    annualized_return_pct NUMERIC(10, 2) NOT NULL,
    cagr_pct NUMERIC(10, 2) NOT NULL,
    max_drawdown_pct NUMERIC(10, 2) NOT NULL,
    sharpe_ratio NUMERIC(8, 3) NOT NULL,
    sortino_ratio NUMERIC(8, 3) NOT NULL,
    win_rate_pct NUMERIC(6, 2) NOT NULL,
    profit_factor NUMERIC(8, 3) NOT NULL,
    trade_count INT NOT NULL,
    avg_win_pct NUMERIC(8, 2) NOT NULL,
    avg_loss_pct NUMERIC(8, 2) NOT NULL,
    expectancy_per_trade_pct NUMERIC(8, 3) NOT NULL,
    exposure_pct NUMERIC(6, 2) NOT NULL,
    annual_turnover_pct NUMERIC(8, 2) NOT NULL,
    net_return_after_costs_pct NUMERIC(10, 2) NOT NULL,
    oos_return_pct NUMERIC(10, 2) NOT NULL,
    benchmark_return_pct NUMERIC(10, 2) NOT NULL,
    alpha_vs_benchmark_pct NUMERIC(10, 2) NOT NULL,
    regime_breakdown_json JSONB NOT NULL,
    validation_status VARCHAR(20) NOT NULL CHECK (validation_status IN ('VALIDATED', 'UNVALIDATED'))
);
