"""
FastAPI Backend Server for the AI-Powered Stock Research, Value Investing & Trading Signal Platform.
Provides REST endpoints for scanning 2,000+ stocks, running walk-forward backtests,
inspecting point-in-time signals, and querying the grounded AI Research Assistant.
"""
from __future__ import annotations
import os
import time
from typing import Dict, Any, List, Optional
from fastapi import FastAPI, HTTPException, Query, Header, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import pandas as pd

from .quant_engine import (
    compute_technical_indicators,
    adjust_for_corporate_actions,
    evaluate_falling_knife_risk,
    evaluate_pump_and_dump_risk,
    evaluate_fundamentals_and_valuation,
    run_walk_forward_backtest,
    generate_explainable_decision,
)

app = FastAPI(
    title="QuantEdge AI — Institutional Stock Research, Value Investing & Trading Signal API",
    version="2.4.0",
    description="Rule-based quantitative stock analysis, falling-knife & pump-dump detection, sector-aware DCF valuation, and walk-forward backtesting engine.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Simple in-memory rate limiter per client key
_RATE_BUCKETS: Dict[str, List[float]] = {}


def verify_rate_limit(x_api_key: Optional[str] = Header(default="public-terminal-client")) -> str:
    now = time.time()
    key = x_api_key or "anon"
    window = [t for t in _RATE_BUCKETS.get(key, []) if now - t < 60.0]
    if len(window) >= 120:
        raise HTTPException(status_code=429, detail="Rate limit exceeded (120 requests/min).")
    window.append(now)
    _RATE_BUCKETS[key] = window
    return key


class BacktestRequest(BaseModel):
    ticker: str = Field(..., example="TCS")
    exchange: str = Field(default="NSE", example="NSE")
    strategy_id: str = Field(default="SWING_PULLBACK_V1", example="SWING_PULLBACK_V1")
    cap_category: str = Field(default="LARGE_CAP")
    ohlcv: List[Dict[str, Any]]
    fundamentals: Dict[str, Any] = Field(default_factory=dict)
    corporate_actions: List[Dict[str, Any]] = Field(default_factory=list)


@app.get("/api/v1/health")
def health_check() -> Dict[str, Any]:
    return {
        "status": "healthy",
        "engine": "QuantEdge-PIT-v2.4",
        "look_ahead_protection": "strict_t_plus_1_open",
        "supported_markets": ["NSE", "BSE", "NASDAQ", "NYSE"],
    }


@app.post("/api/v1/analyze")
def analyze_stock_endpoint(
    req: BacktestRequest, _client: str = Depends(verify_rate_limit)
) -> Dict[str, Any]:
    if not req.ohlcv or len(req.ohlcv) < 10:
        return {
            "ticker": req.ticker,
            "exchange": req.exchange,
            "status": "DATA_UNAVAILABLE",
            "action_state": "AVOID",
            "warning": "Insufficient or missing historical OHLCV bars. Refusing to fabricate signal.",
        }
    df = pd.DataFrame(req.ohlcv)
    if req.corporate_actions:
        df = adjust_for_corporate_actions(df, req.corporate_actions)
    ind_df = compute_technical_indicators(df)
    bt = run_walk_forward_backtest(
        ind_df, strategy_id=req.strategy_id, market=req.exchange, cap_category=req.cap_category
    )
    decision = generate_explainable_decision(
        {"ticker": req.ticker, "exchange": req.exchange, "sector": req.fundamentals.get("sector", "General")},
        ind_df,
        req.fundamentals,
        bt,
    )
    return {
        "ticker": req.ticker,
        "exchange": req.exchange,
        "status": "OK",
        "decision": decision,
    }
