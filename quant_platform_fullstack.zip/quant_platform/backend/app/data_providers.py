"""
Market Data Provider Adapters for Indian (NSE/BSE) and International (US) Equities.
Strictly distinguishes LIVE, DELAYED_15M, EOD, HISTORICAL_PIT, and DATA_UNAVAILABLE states.
Never fabricates prices or financial statements when a provider fails.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Any, List, Optional
import os
import pandas as pd


@dataclass
class MarketDataResult:
    ticker: str
    exchange: str
    status: str  # OK, DATA_UNAVAILABLE, STALE_WARNING, RATE_LIMITED
    freshness: str  # LIVE, DELAYED_15M, EOD, HISTORICAL_PIT, UNAVAILABLE
    provider_name: str
    as_of_timestamp: str
    ohlcv_df: Optional[pd.DataFrame] = None
    fundamentals: Optional[Dict[str, Any]] = None
    warning_message: Optional[str] = None


class MarketDataProviderAdapter(ABC):
    """Abstract base interface for licensed or public market data feeds."""

    @abstractmethod
    def fetch_historical_ohlcv(
        self, ticker: str, exchange: str, timeframe: str = "1D"
    ) -> MarketDataResult:
        pass

    @abstractmethod
    def fetch_point_in_time_fundamentals(
        self, ticker: str, exchange: str
    ) -> Dict[str, Any]:
        pass


class LicensedBrokerOrVendorAdapter(MarketDataProviderAdapter):
    """
    Production adapter interface for licensed Indian & Global market data APIs:
      - NSE/BSE Live & EOD: Zerodha Kite Connect, Upstox API, TrueData, or NSE Bhavcopy EOD
      - Fundamentals & Corporate Actions: Refinitiv / Capitaline / Screener / FinancialModelingPrep
      - US Equities: Polygon.io / AlphaVantage / IEX Cloud
    """

    def __init__(self, provider_name: str = "KiteConnect_NSE", api_key: Optional[str] = None):
        self.provider_name = provider_name
        self.api_key = api_key or os.getenv("MARKET_DATA_API_KEY", "")

    def fetch_historical_ohlcv(
        self, ticker: str, exchange: str, timeframe: str = "1D"
    ) -> MarketDataResult:
        if not self.api_key:
            return MarketDataResult(
                ticker=ticker,
                exchange=exchange,
                status="DATA_UNAVAILABLE",
                freshness="UNAVAILABLE",
                provider_name=self.provider_name,
                as_of_timestamp="N/A",
                ohlcv_df=None,
                warning_message=(
                    f"API key not configured for {self.provider_name}. "
                    "Set MARKET_DATA_API_KEY in .env or switch to PointInTimeSnapshotAdapter."
                ),
            )
        # When configured in a live networked deployment, executes authenticated REST request
        raise NotImplementedError("Configure live outbound network credentials in .env")

    def fetch_point_in_time_fundamentals(
        self, ticker: str, exchange: str
    ) -> Dict[str, Any]:
        if not self.api_key:
            return {
                "data_unavailable": True,
                "warning": f"Missing API credentials for {self.provider_name} fundamental feed.",
            }
        raise NotImplementedError("Configure live fundamental provider credentials in .env")


class PointInTimeSnapshotAdapter(MarketDataProviderAdapter):
    """
    Verified Point-in-Time Historical & EOD Adapter backed by recorded exchange series.
    Returns explicit DATA_UNAVAILABLE warnings if a requested ticker is missing or stale.
    """

    def __init__(self, store: Dict[str, Dict[str, Any]]):
        self.store = store

    def fetch_historical_ohlcv(
        self, ticker: str, exchange: str, timeframe: str = "1D"
    ) -> MarketDataResult:
        key = f"{ticker.upper()}:{exchange.upper()}"
        record = self.store.get(key) or self.store.get(ticker.upper())
        if not record or "ohlcv" not in record or len(record["ohlcv"]) == 0:
            return MarketDataResult(
                ticker=ticker,
                exchange=exchange,
                status="DATA_UNAVAILABLE",
                freshness="UNAVAILABLE",
                provider_name="GoogleFinance_Verified_EOD",
                as_of_timestamp="N/A",
                ohlcv_df=None,
                warning_message=f"DATA UNAVAILABLE: No verified OHLCV series found for {key}. Signals suppressed.",
            )
        df = pd.DataFrame(record["ohlcv"])
        return MarketDataResult(
            ticker=ticker,
            exchange=exchange,
            status="OK",
            freshness=record.get("freshness", "EOD"),
            provider_name=record.get("provider", "GoogleFinance_NSE_NASDAQ_EOD"),
            as_of_timestamp=record.get("as_of", "2026-10-19T15:30:00+05:30"),
            ohlcv_df=df,
            fundamentals=record.get("fundamentals", {}),
        )

    def fetch_point_in_time_fundamentals(
        self, ticker: str, exchange: str
    ) -> Dict[str, Any]:
        key = f"{ticker.upper()}:{exchange.upper()}"
        record = self.store.get(key) or self.store.get(ticker.upper())
        if not record or "fundamentals" not in record:
            return {"data_unavailable": True, "warning": f"Fundamentals unavailable for {key}"}
        return record["fundamentals"]
