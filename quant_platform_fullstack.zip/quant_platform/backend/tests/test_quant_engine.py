"""
Comprehensive Unit & Integration Test Suite for the Quantitative Stock Analysis & Backtesting Engine.
Compatible with both `python3 -m unittest` and `pytest`.
"""
import unittest
import numpy as np
import pandas as pd

from backend.app.quant_engine import (
    TransactionCostModel,
    adjust_for_corporate_actions,
    compute_technical_indicators,
    evaluate_falling_knife_risk,
    evaluate_pump_and_dump_risk,
    evaluate_fundamentals_and_valuation,
    run_walk_forward_backtest,
    generate_explainable_decision,
)
from backend.app.data_providers import PointInTimeSnapshotAdapter


def _make_ohlcv_series(prices: list, volumes: list = None, upper_wicks: list = None) -> pd.DataFrame:
    dates = pd.date_range("2025-10-01", periods=len(prices), freq="B")
    vols = volumes if volumes is not None else [1_000_000] * len(prices)
    rows = []
    for i, p in enumerate(prices):
        wick_mult = upper_wicks[i] if (upper_wicks and i < len(upper_wicks)) else 0.008
        o = p * 0.996
        c = float(p)
        h = max(o, c) * (1.0 + wick_mult)
        l = min(o, c) * 0.992
        rows.append({
            "date": dates[i].strftime("%Y-%m-%d"),
            "open": round(o, 2),
            "high": round(h, 2),
            "low": round(l, 2),
            "close": round(c, 2),
            "volume": int(vols[i]),
        })
    return pd.DataFrame(rows)


class TestQuantEngine(unittest.TestCase):
    def test_1_corporate_action_split_and_dividend_adjustment(self):
        df = pd.DataFrame([
            {"date": "2026-01-01", "open": 1000.0, "high": 1020.0, "low": 990.0, "close": 1000.0, "volume": 10000},
            {"date": "2026-01-02", "open": 500.0, "high": 510.0, "low": 495.0, "close": 505.0, "volume": 20000},
        ])
        actions = [{"ex_date": "2026-01-02", "action_type": "SPLIT", "ratio_from": 1, "ratio_to": 2}]
        adj = adjust_for_corporate_actions(df, actions)
        self.assertTrue(np.isclose(adj.iloc[0]["close"], 500.0))
        self.assertEqual(adj.iloc[0]["volume"], 20000)
        self.assertTrue(np.isclose(adj.iloc[1]["close"], 505.0))

    def test_2_falling_knife_never_buys_solely_on_steep_drop(self):
        prices = np.linspace(1000, 550, 60).tolist()
        df = compute_technical_indicators(_make_ohlcv_series(prices))
        fundamentals = {
            "eps": 45.0,
            "pe_ratio": 12.2,
            "book_value_per_share": 300.0,
            "roe_pct": 18.0,
            "roic_pct": 16.0,
            "revenue_growth_yoy_pct": 10.0,
            "eps_growth_yoy_pct": 12.0,
            "operating_margin_pct": 20.0,
            "fcf_to_net_profit_pct": 85.0,
            "debt_to_equity": 0.1,
            "interest_coverage": 15.0,
        }
        fk = evaluate_falling_knife_risk(df, fundamentals)
        self.assertIn(fk["risk_level"], ("HIGH", "EXTREME"))
        self.assertFalse(fk["stabilization_confirmed"])

        bt = run_walk_forward_backtest(df)
        decision = generate_explainable_decision({"sector": "IT Services"}, df, fundamentals, bt)
        self.assertIn(decision["action_state"], ("WAIT", "SELL", "AVOID"))
        self.assertNotEqual(decision["action_state"], "BUY")

    def test_3_false_breakout_and_pump_dump_blocks_buy(self):
        prices = [100.0 + i * 0.2 for i in range(55)] + [112.0, 132.0, 118.0, 111.0, 108.0]
        vols = [500_000] * 55 + [600_000, 4_500_000, 3_200_000, 1_800_000, 1_200_000]
        wicks = [0.005] * 55 + [0.01, 0.08, 0.05, 0.03, 0.02]
        df = compute_technical_indicators(_make_ohlcv_series(prices, vols, wicks))
        weak_fund = {
            "eps": 1.2,
            "pe_ratio": 90.0,
            "roe_pct": 3.5,
            "eps_growth_yoy_pct": -15.0,
            "promoter_pledge_pct": 42.0,
            "debt_to_equity": 2.4,
        }
        pd_res = evaluate_pump_and_dump_risk(df, weak_fund)
        self.assertIn(pd_res["label"], ("High pump-and-reversal risk", "Possible false breakout"))
        bt = run_walk_forward_backtest(df)
        decision = generate_explainable_decision({"sector": "Telecom"}, df, weak_fund, bt)
        self.assertIn(decision["action_state"], ("AVOID", "WAIT"))

    def test_4_low_pe_value_trap_is_detected_and_not_bought(self):
        fund = {
            "eps": 20.0,
            "pe_ratio": 7.5,
            "book_value_per_share": 140.0,
            "roe_pct": 6.5,
            "roic_pct": 5.2,
            "revenue_growth_yoy_pct": -9.0,
            "eps_growth_yoy_pct": -18.0,
            "operating_margin_pct": 8.0,
            "operating_margin_prev_pct": 13.5,
            "fcf_to_net_profit_pct": 25.0,
            "debt_to_equity": 1.85,
            "interest_coverage": 1.6,
        }
        val = evaluate_fundamentals_and_valuation(150.0, "Industrials", fund)
        self.assertTrue(val["is_value_trap"])
        self.assertTrue(val["is_business_deteriorating"])

    def test_5_transaction_cost_and_no_lookahead_backtest(self):
        x = np.linspace(0, 6 * np.pi, 140)
        prices = (200.0 + np.linspace(0, 80, 140) + 12.0 * np.sin(x)).tolist()
        df = compute_technical_indicators(_make_ohlcv_series(prices))
        bt = run_walk_forward_backtest(df, market="NSE", cap_category="LARGE_CAP")
        self.assertGreater(bt["round_trip_cost_pct"], 0.25)
        self.assertLessEqual(bt["net_return_after_costs_pct"], bt["total_gross_return_pct"])
        for t in bt["trades"]:
            self.assertGreater(t["entry_date"], t["signal_date"])

    def test_6_missing_data_returns_warning_never_fabricates(self):
        adapter = PointInTimeSnapshotAdapter({})
        res = adapter.fetch_historical_ohlcv("NONEXISTENT", "NSE")
        self.assertEqual(res.status, "DATA_UNAVAILABLE")
        self.assertIsNone(res.ohlcv_df)
        decision = generate_explainable_decision(
            {"ticker": "NONEXISTENT", "data_unavailable": True}, pd.DataFrame(), {}, {}
        )
        self.assertEqual(decision["action_state"], "AVOID")
        self.assertEqual(decision["data_quality"], "DATA_UNAVAILABLE")


if __name__ == "__main__":
    unittest.main(verbosity=2)
